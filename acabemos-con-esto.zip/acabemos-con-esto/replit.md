# BiblioDigital - Biblioteca Digital Personal

## Overview
BiblioDigital is a personal digital library web application designed to allow users to manage, read, and organize their digital books. It operates entirely client-side using local storage mechanisms (localStorage and IndexedDB), eliminating the need for a backend or external database for core functionality. The project aims to provide a privacy-focused, easy-to-use digital library solution with features like book cataloging, personalized reading settings, and a responsive design.

## User Preferences
No explicit user preferences were provided in the original `replit.md` file.

## System Architecture

### UI/UX Decisions
-   **Responsive Design**: The application features a professional and modern interface, fully adapted for mobile, tablets, and desktop, including a collapsible sidebar and optimized layouts.
-   **Theming**: 9 modern visual themes are available, each with a complete color palette, custom gradients, shadows, and adapted styles for all UI elements, ensuring excellent contrast and legibility.
-   **Authentication Flow**: Designed for optional local authentication. Users can explore content as guests, with login only required for uploading personal books.

### Technical Implementations
-   **Frontend**: Built with HTML5, CSS3 (using variables for styling), and Vanilla JavaScript for application logic.
-   **Book Management**: Includes a catalog with search and filters, book uploads with custom covers (base64 conversion), demo books, a favorites feature, and an integrated reader with customizable font size and theme. A "Fiction Express Reader" provides a paginated reading experience for JSON-formatted books.
-   **Local Authentication**: User registration and login are handled via localStorage, storing user data locally without an external authentication server.
-   **Customizable Settings**: Users can edit their profile, configure visual themes, global font size, reader themes (Light, Dark, Sepia), and manage notification and password settings for local authentication.

### System Design Choices
-   **Local Storage First**: The core design principle focuses on client-side operation using browser storage.
    -   **localStorage**: Used for user data (authentication), book metadata (title, author, category, description), favorites, custom settings, and book covers (base64 images).
    -   **IndexedDB**: Employed for storing larger binary files, specifically PDF files (up to 50MB per file), overcoming localStorage limits and providing better performance for binary data. The database `BiblioDigitalDB` stores PDFs using `bookId` as key and `pdfDataUrl` (base64) as value.
-   **Server**: A simple Python 3 `http.server` is used for serving static files during development, configured to run on `0.0.0.0:5000` with caching disabled for development.
-   **Security Considerations (Development)**: Local authentication and storage are for demonstration. Production systems would require password hashing, JWT-based authentication, HTTPS, input validation, and sanitization.

## External Dependencies
-   **Python 3.11**: Used for the `http.server` module to serve static files during development.
-   **Node.js 20**: Required for npm and Firebase CLI tools.
-   **Firebase SDK v10.7.1**: Integrated for Firestore, Authentication, and Storage capabilities. Loaded from CDN using the compat API, with services exposed globally. Firebase integration includes robust fallbacks to local storage if Firebase services are unavailable.
-   **Firebase CLI v14.20.0**: Used for deployment and management.
-   **PDF.js v3.11.174**: Utilized for PDF rendering and navigation within the advanced reader.
-   **epub.js v0.3.93**: Used for EPUB support in the advanced reader.